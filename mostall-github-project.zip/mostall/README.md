# Mostall

A polished, interactive fictional business-management dashboard built as a mobile-first web app.

## Features

- Interactive company dashboard
- Revenue, profit, customers, reputation, cash and company value stats
- Monthly business simulation
- CEO decisions and changing company metrics
- Animated charts and micro-interactions
- Live activity feed
- Fictional Mostall Social feed
- Post updates, like posts, and view trends
- Responsive mobile/desktop design
- Dark editorial visual style with Apple-inspired motion and typography

## Run locally

No build step is required.

Open `index.html` in a browser, or serve the folder with any static web server:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy to GitHub Pages

1. Create a GitHub repository.
2. Upload the contents of this folder.
3. Go to **Settings → Pages**.
4. Select the `main` branch and `/ (root)`.
5. Save. GitHub Pages will publish `index.html`.

## Project structure

```text
mostall/
├── index.html
├── README.md
├── LICENSE
├── .gitignore
└── assets/
```

## Note

Mostall and the social-media content in this project are fictional. The project is intended as an interactive simulation/demo.
