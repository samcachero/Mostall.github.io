---
name: Bug report
about: Report something that is not working
title: "[Bug] "
labels: bug
---

## What happened?

## Steps to reproduce

1.
2.
3.

## Device / browser

## Screenshots
